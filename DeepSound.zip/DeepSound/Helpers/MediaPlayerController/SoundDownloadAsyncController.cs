﻿//###############################################################
// Author >> Elin Doughouz 
// Copyright (c) DeepSound 25/04/2019 All Right Reserved
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// Follow me on facebook >> https://www.facebook.com/Elindoughous
//=========================================================

using System;
using System.IO;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Database;
using Android.Graphics;
using Android.Widget;
using DeepSound.Activities.Tabbes;
using DeepSound.Helpers.Fonts;
using DeepSound.SQLite;
using DeepSoundClient.Classes.Global;

namespace DeepSound.Helpers.MediaPlayerController
{ 
    public class SoundDownloadAsyncController
    {
        private readonly DownloadManager Downloadmanager;
        private readonly DownloadManager.Request Request;

        private readonly string FilePath = Android.OS.Environment.ExternalStorageDirectory + "/" + AppSettings.ApplicationName + "/";
        private readonly string Filename;
        private long DownloadId;
        private string FromActivity;
        private SoundDataObject Sound;
        private readonly HomeActivity ActivityContext;
         
        public SoundDownloadAsyncController(string url, string filename, Context contextActivity)
        {
            try
            {
                ActivityContext = (HomeActivity)contextActivity;
                
                if (!Directory.Exists(FilePath))
                    Directory.CreateDirectory(FilePath);

                if (!filename.Contains(".mp3"))
                    Filename = filename + ".mp3";
                else
                    Filename = filename;
                 
                Downloadmanager = (DownloadManager)Application.Context.GetSystemService(Context.DownloadService);
                Request = new DownloadManager.Request(Android.Net.Uri.Parse(url));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void StartDownloadManager(string title, SoundDataObject sound, string fromActivity)
        {
            try
            {
                if (sound != null && !string.IsNullOrEmpty(title))
                {
                    Sound = sound;
                    FromActivity = fromActivity;

                    var sqlEntity = new SqLiteDatabase();
                    sqlEntity.InsertOrUpdate_LatestDownloadsSound(Sound);
                    sqlEntity.Dispose();

                    Request.SetTitle(title);
                    Request.SetAllowedNetworkTypes(DownloadNetwork.Mobile | DownloadNetwork.Wifi);
                    Request.SetDestinationInExternalPublicDir("/" + AppSettings.ApplicationName + "/", Filename);
                    Request.SetNotificationVisibility(DownloadVisibility.Visible);
                    Request.SetAllowedOverRoaming(true);
                    Request.SetVisibleInDownloadsUi(true);
                    DownloadId = Downloadmanager.Enqueue(Request);


                    OnDownloadComplete onDownloadComplete = new OnDownloadComplete
                    {
                        ActivityContext = ActivityContext, TypeActivity = fromActivity,
                        Sound = Sound
                    };

                    Application.Context.ApplicationContext.RegisterReceiver(onDownloadComplete, new IntentFilter(DownloadManager.ActionDownloadComplete));
                }
                else
                {
                    Toast.MakeText(ActivityContext, ActivityContext.GetText(Resource.String.Lbl_Download_failed), ToastLength.Short).Show();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public void StopDownloadManager()
        {
            try
            {
                Downloadmanager.Remove(DownloadId);
                RemoveDiskSoundFile(Filename);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        public bool RemoveDiskSoundFile(string filename)
        {
            try
            {
                string path = Android.OS.Environment.ExternalStorageDirectory + "/" + AppSettings.ApplicationName + "/" + filename;
                if (File.Exists(path))
                {
                    var sqlEntity = new SqLiteDatabase();
                    sqlEntity.Remove_LatestDownloadsSound(int.Parse(filename.Replace(".mp3", "")));
                    File.Delete(path);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return false;
            }
        }

        public bool CheckDownloadLinkIfExits()
        {
            try
            {
                if (File.Exists(FilePath + Filename))
                    return true;

                return false;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return false;
            }
        }

        public static string GetDownloadedDiskSoundUri(string url)
        {
            try
            {
                string filename = url.Split('/').Last();

                var fullpaths = "file://" + Android.Net.Uri.Parse(Android.OS.Environment.ExternalStorageDirectory + "/" + AppSettings.ApplicationName + "/" + filename + ".mp3");
                if (File.Exists(fullpaths))
                    return fullpaths;

                var fullpath2 =  Android.OS.Environment.ExternalStorageDirectory + "/" + AppSettings.ApplicationName + "/" + filename + ".mp3";
                if (File.Exists(fullpath2))
                    return fullpath2;

                
                var fullpath3 = Android.OS.Environment.ExternalStorageDirectory + "/" + AppSettings.ApplicationName + "/" + filename + ".mp3";
                if (File.Exists(fullpath3))
                    return fullpath3;
                
                return null;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        [BroadcastReceiver()]
        [IntentFilter(new[] { DownloadManager.ActionDownloadComplete })]
        public class OnDownloadComplete : BroadcastReceiver
        {
            public Context ActivityContext;
            public string TypeActivity;
            public SoundDataObject Sound;
             
            public override void OnReceive(Context context, Intent intent)
            {
                try
                { 
                    if (intent.Action == DownloadManager.ActionDownloadComplete )
                    {
                        if (ActivityContext == null)
                            return;

                        DownloadManager downloadManagerExcuter = (DownloadManager)Application.Context.GetSystemService(Context.DownloadService);
                        long downloadId = intent.GetLongExtra(DownloadManager.ExtraDownloadId, -1);
                        DownloadManager.Query query = new DownloadManager.Query();
                        query.SetFilterById(downloadId);
                        ICursor c = downloadManagerExcuter.InvokeQuery(query);
                        var sqlEntity = new SqLiteDatabase();

                        if (c.MoveToFirst())
                        {
                            int columnIndex = c.GetColumnIndex(DownloadManager.ColumnStatus);
                            if (c.GetInt(columnIndex) == (int)DownloadStatus.Successful)
                            {
                                string downloadedPath = c.GetString(c.GetColumnIndex(DownloadManager.ColumnLocalUri));

                                ActivityManager.RunningAppProcessInfo appProcessInfo = new ActivityManager.RunningAppProcessInfo();
                                ActivityManager.GetMyMemoryState(appProcessInfo);
                                if (appProcessInfo.Importance == Importance.Foreground ||  appProcessInfo.Importance == Importance.Background)
                                {

                                    sqlEntity.InsertOrUpdate_LatestDownloadsSound(Sound.Id, downloadedPath);
                                    if (TypeActivity == "Main")
                                    {
                                        if (ActivityContext is HomeActivity tabbedMain)
                                        {
                                            tabbedMain.SoundController.BtnIconDownload.Tag = "Downloaded";
                                            FontUtils.SetTextViewIcon(FontsIconFrameWork.IonIcons, tabbedMain.SoundController.BtnIconDownload, IonIconsFonts.CheckmarkCircled);
                                            tabbedMain.SoundController.BtnIconDownload.SetTextColor(Color.Red);
 
                                            tabbedMain.LibrarySynchronizer.AddToLatestDownloads(Sound);
                                        }
                                    } 
                                }
                                else
                                {
                                    sqlEntity.InsertOrUpdate_LatestDownloadsSound(Sound.Id, downloadedPath); 
                                }
                            }
                        }

                        sqlEntity.Dispose();
                    }
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }
            }
        }
    }
}