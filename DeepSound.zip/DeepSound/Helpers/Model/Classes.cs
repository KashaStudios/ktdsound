﻿namespace DeepSound.Helpers.Model
{
    public class Classes
    {
        public class LibraryItem
        {
            public string SectionId { get; set; }
            public string SectionText { get; set; }
            public int SongsCount { get; set; }
            public string BackgroundImage { get; set; }
        }
    }
}