﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Gms.Auth.Api;
using DeepSound.Activities.Albums;
using DeepSound.Activities.Default;
using DeepSound.Activities.SettingsUser;
using DeepSound.Activities.Tabbes;
using DeepSound.Helpers.MediaPlayerController;
using DeepSound.Helpers.Model;
using DeepSound.Helpers.Utils;
using DeepSound.Library.OneSignal;
using DeepSound.SQLite;
using DeepSoundClient;
using DeepSoundClient.Classes.Common;
using DeepSoundClient.Classes.Playlist;
using DeepSoundClient.Classes.User;
using DeepSoundClient.Requests;
using Java.IO;
using Java.Lang;
using Xamarin.Facebook;
using Xamarin.Facebook.Login;
using Console = System.Console;
using Exception = System.Exception;

namespace DeepSound.Helpers.Controller
{
    public static class ApiRequest
    { 
        public static async Task GetSettings_Api()
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    (int apiStatus, var respond) = await Current.GetOptionsAsync();
                    if (apiStatus == 200)
                    {
                        if (respond is OptionsObject result)
                        { 
                            ListUtils.SettingsSiteList.Clear();
                            ListUtils.SettingsSiteList.Add(result.DataOptions);
                            
                            SqLiteDatabase dbDatabase = new SqLiteDatabase();
                            dbDatabase.InsertOrUpdateSettings(result.DataOptions);
                            dbDatabase.Dispose();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public static async Task<ProfileObject> GetInfoData(string userId)
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    var (apiStatus, respond) = await RequestsAsync.User.ProfileAsync(userId, "followers,following,albums,activities,latest_songs,top_songs,store").ConfigureAwait(false);
                    if (apiStatus == 200)
                    {
                        if (respond is ProfileObject result)
                        {
                            if (userId == UserDetails.UserId.ToString())
                            {
                                if (result.Data != null)
                                {
                                    UserDetails.Avatar = result.Data.Avatar;
                                    UserDetails.Username = result.Data.Username;
                                    UserDetails.IsPro = result.Data.IsPro.ToString();
                                    UserDetails.Url = result.Data.Url;
                                    UserDetails.FullName = result.Data.Name;

                                    ListUtils.MyUserInfoList.Clear();
                                    ListUtils.MyUserInfoList.Add(result.Data);

                                    SqLiteDatabase dbDatabase = new SqLiteDatabase();
                                    dbDatabase.InsertOrUpdate_DataMyInfo(result.Data);
                                    dbDatabase.Dispose();
                                }
                                 
                                return result;
                            }

                            return result;
                        }
                    }
                }

                return null;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }
         
        public static async Task<(int?, int?)> GetCountNotifications()
        {
            var (respondCode, respondString) = await RequestsAsync.Common.GetCountNotificationsAsync().ConfigureAwait(false);
            if (respondCode.Equals(200))
            {
                if (respondString is NotificationsCountObject Object)
                {
                    return (Object.Count, Object.Msgs);
                }
            }
            return (0, 0);
        }


        public static async Task GetGenres_Api()
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    (int apiStatus, var respond) = await RequestsAsync.User.GenresAsync().ConfigureAwait(false);
                    if (apiStatus == 200)
                    {
                        if (respond is GenresObject result)
                        {
                            ListUtils.GenresList.Clear();
                            ListUtils.GenresList = new ObservableCollection<GenresObject.DataGenres>(result.Data);
                             
                            SqLiteDatabase dbDatabase = new SqLiteDatabase();
                            dbDatabase.InsertOrUpdate_Genres(ListUtils.GenresList);
                            dbDatabase.Dispose();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static async Task GetMyPlaylist_Api()
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    (int apiStatus, var respond) = await RequestsAsync.Playlist.GetPlaylistAsync(UserDetails.UserId.ToString());
                    if (apiStatus.Equals(200))
                    {
                        if (respond is PlaylistsObject result)
                        {
                            HomeActivity.GetInstance().PlaylistFragment.PlaylistAdapter.PlaylistList = new ObservableCollection<PlaylistDataObject>(result.Playlists);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public static async Task GetPrices_Api()
        {
            try
            {
                if (Methods.CheckConnectivity())
                {
                    (int apiStatus, var respond) = await RequestsAsync.Common.GetPricesAsync().ConfigureAwait(false);
                    if (apiStatus == 200)
                    {
                        if (respond is PricesObject result)
                        {
                            ListUtils.PriceList.Clear();
                            ListUtils.PriceList = new ObservableCollection<PricesObject.DataPrice>(result.Data);
                             
                            SqLiteDatabase dbDatabase = new SqLiteDatabase();
                            dbDatabase.InsertOrUpdate_Price(ListUtils.PriceList);
                            dbDatabase.Dispose();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public static bool RunLogout;

        public static async void Delete(Activity context)
        {
            try
            {
                if (RunLogout == false)
                {
                    RunLogout = true;

                    await RemoveData("Delete");

                    context.RunOnUiThread(() =>
                    {
                        Methods.Path.DeleteAll_MyFolderDisk();

                        SqLiteDatabase dbDatabase = new SqLiteDatabase();

                        Runtime.GetRuntime().RunFinalization();
                        Runtime.GetRuntime().Gc();
                        TrimCache(context);

                        dbDatabase.ClearAll();
                        dbDatabase.DropAll();

                        ListUtils.ClearAllList();

                        UserDetails.ClearAllValueUserDetails();

                        dbDatabase.CheckTablesStatus();
                        dbDatabase.Dispose();

                        SharedPref.SharedData.Edit().Clear().Commit();

                        Intent intent = new Intent(context, typeof(FirstActivity));
                        intent.AddCategory(Intent.CategoryHome);
                        intent.SetAction(Intent.ActionMain);
                        intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
                        context.StartActivity(intent);
                        context.FinishAffinity();
                        context.Finish();
                    });

                    RunLogout = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public static async void Logout(Activity context)
        {
            try
            {
                if (RunLogout == false)
                {
                    RunLogout = true;

                    await RemoveData("Logout");

                    context.RunOnUiThread(() =>
                    {
                        Methods.Path.DeleteAll_MyFolderDisk();

                        SqLiteDatabase dbDatabase = new SqLiteDatabase();

                        Runtime.GetRuntime().RunFinalization();
                        Runtime.GetRuntime().Gc();
                        TrimCache(context);

                        dbDatabase.ClearAll();
                        dbDatabase.DropAll();

                        ListUtils.ClearAllList();

                        UserDetails.ClearAllValueUserDetails();

                        dbDatabase.CheckTablesStatus();
                        dbDatabase.Dispose();

                        SharedPref.SharedData.Edit().Clear().Commit(); 

                        Intent intent = new Intent(context, typeof(FirstActivity));
                        intent.AddCategory(Intent.CategoryHome);
                        intent.SetAction(Intent.ActionMain);
                        intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask | ActivityFlags.ClearTask);
                        context.StartActivity(intent);
                        context.FinishAffinity();
                        context.Finish();
                    });

                    RunLogout = false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void TrimCache(Activity context)
        {
            try
            {
                File dir = context.CacheDir;
                if (dir != null && dir.IsDirectory)
                {
                    DeleteDir(dir);
                }

                context.DeleteDatabase("DeepSoundMusic.db");
                context.DeleteDatabase(SqLiteDatabase.PathCombine);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static bool DeleteDir(File dir)
        {
            try
            {
                if (dir == null || !dir.IsDirectory) return dir != null && dir.Delete();
                string[] children = dir.List();
                foreach (string child in children)
                {
                    bool success = DeleteDir(new File(dir, child));
                    if (!success)
                    {
                        return false;
                    }
                }

                // The directory is now empty so delete it
                return dir.Delete();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        public static async Task RemoveData(string type)
        {
            try
            {
                if (type == "Logout")
                {
                    if (Methods.CheckConnectivity())
                    {
                        await RequestsAsync.Auth.LogoutAsync();
                    }
                }
                else if (type == "Delete")
                {
                    Methods.Path.DeleteAll_MyFolder();

                    if (Methods.CheckConnectivity())
                    {
                        await RequestsAsync.User.DeleteAccountAsync(UserDetails.UserId.ToString(), UserDetails.Password);
                    }
                }

                try
                {
                    if (AppSettings.ShowGoogleLogin && LoginActivity.MGoogleApiClient != null)
                        if (Auth.GoogleSignInApi != null)
                            Auth.GoogleSignInApi.SignOut(LoginActivity.MGoogleApiClient);

                    if (AppSettings.ShowFacebookLogin)
                    {
                        var accessToken = AccessToken.CurrentAccessToken;
                        var isLoggedIn = accessToken != null && !accessToken.IsExpired;
                        if (isLoggedIn && Profile.CurrentProfile != null)
                        {
                            LoginManager.Instance.LogOut();
                        }
                    }

                    AlbumsFragment.MAdapter?.SoundsList?.Clear();

                    OneSignalNotification.UnRegisterNotificationDevice();

                    UserDetails.ClearAllValueUserDetails();

                    Constant.MediaPlayer.Release();

                    GC.Collect();
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception);
                }

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}