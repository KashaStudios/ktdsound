﻿using System;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Widget;
using DeepSound.Activities.Default;
using DeepSound.Activities.Tabbes;
using DeepSound.Helpers.Controller;
using DeepSound.SQLite;
using DeepSoundClient;

namespace DeepSound.Activities
{
    [Activity(MainLauncher = true, Icon = "@drawable/icon", Theme = "@style/SplashScreenTheme", NoHistory = true, ConfigurationChanges = ConfigChanges.Locale | ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class SplashScreenActivity : Activity
    {
        #region Variables Basic

        private SqLiteDatabase DbDatabase;

        #endregion

        protected override void OnCreate(Bundle savedInstanceState)
        {
            try
            {
                base.OnCreate(savedInstanceState);

                DbDatabase = new SqLiteDatabase();
                DbDatabase.CheckTablesStatus();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        protected override void OnResume()
        {
            try
            {
                base.OnResume();
                Task startupWork = new Task(FirstRunExcite);
                startupWork.Start(); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
 
        private void FirstRunExcite()
        {
            try
            {
                DbDatabase = new SqLiteDatabase();
                DbDatabase.CheckTablesStatus();
                
                if (AppSettings.Lang != "")
                {
                    LangController.SetApplicationLang(this, AppSettings.Lang);
                }
                else
                {
                    var langLocale = Resources.Configuration.Locale;
                    LangController.SetAppLanguage(this);
                }

                var result = DbDatabase.Get_data_Login_Credentials();
                if (result != null)
                {
                    Current.AccessToken = result.AccessToken;

                    switch (result.Status)
                    {
                        case "Active":
                        case "Pending":
                            StartActivity(new Intent(Application.Context, typeof(HomeActivity)));
                            break;
                        default:
                            StartActivity(new Intent(Application.Context, typeof(FirstActivity)));
                            break;
                    }
                }
                else
                {
                    StartActivity(new Intent(Application.Context, typeof(FirstActivity)));
                }
                DbDatabase.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Toast.MakeText(this, e.Message, ToastLength.Short).Show();
            }
        }
    }
}