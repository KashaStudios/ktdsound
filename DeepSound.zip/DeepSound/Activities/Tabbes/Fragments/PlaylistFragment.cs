﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using Com.Liaoinstan.SpringViewLib.Container;
using Com.Liaoinstan.SpringViewLib.Widgets;
using DeepSound.Activities.Library;
using DeepSound.Activities.Playlist;
using DeepSound.Activities.Playlist.Adapters;
using DeepSound.Helpers.Controller;
using DeepSound.Helpers.Model;
using DeepSound.Helpers.Utils;
using DeepSoundClient.Classes.Playlist;
using DeepSoundClient.Requests;
using Newtonsoft.Json;
using DefaultHeader = DeepSound.Helpers.PullSwipeStyles.DefaultHeader;
using Toolbar = Android.Support.V7.Widget.Toolbar;

namespace DeepSound.Activities.Tabbes.Fragments
{
    public class PlaylistFragment : Fragment, SpringView.IOnFreshListener
    {
        #region Variables Basic

        public HPlaylistAdapter PlaylistAdapter;
        private HPlaylistAdapter PublicPlaylistAdapter;
        private HomeActivity GlobalContext;
        private SpringView SwipeRefreshLayout;
        private ViewStub EmptyStateLayout, PublicPlaylistViewStub, PlaylistViewStub;
        private View Inflated , PublicPlaylistInflated, PlaylistInflated;
        private RecyclerViewOnScrollListener PlaylistScrollEvent, PublicPlaylistScrollEvent;
        private PlaylistProfileFragment PlaylistProfileFragment;
        private ProgressBar ProgressBar;
        private FloatingActionButton BtnAdd;
        public MyPlaylistFragment MyPlaylistFragment;
        private TemplateRecyclerInflater recyclerInflaterPlaylist, recyclerInflaterPublicPlaylist;
       
        #endregion

        #region General

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            HasOptionsMenu = true;
            // Create your fragment here
            GlobalContext = (HomeActivity)Activity;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                View view = inflater.Inflate(Resource.Layout.TPlaylistLayout, container, false);

                InitComponent(view);
                InitToolbar(view);
                SetRecyclerViewAdapters();

                if (Build.VERSION.SdkInt >= BuildVersionCodes.Lollipop)
                {
                    Activity.Window.ClearFlags(WindowManagerFlags.TranslucentStatus);
                    Activity.Window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
                    Activity.Window.SetStatusBarColor(Color.ParseColor(AppSettings.MainColor));
                }

                StartApiService(); 
                return view;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }
         
        public override void OnLowMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration);
                base.OnLowMemory();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
 
        #endregion
         
        #region Functions

        private void InitComponent(View view)
        {
            try
            {
                ProgressBar = view.FindViewById<ProgressBar>(Resource.Id.progress);
                ProgressBar.Visibility = ViewStates.Visible;

                PlaylistViewStub = (ViewStub)view.FindViewById(Resource.Id.viewStubPlaylist);
                PublicPlaylistViewStub = (ViewStub)view.FindViewById(Resource.Id.viewStubPublicePlaylist);
                EmptyStateLayout = (ViewStub)view.FindViewById(Resource.Id.viewStub);
               
                SwipeRefreshLayout = (SpringView)view.FindViewById(Resource.Id.material_style_ptr_frame);
                SwipeRefreshLayout.SetType(SpringView.Types.Overlap);
                SwipeRefreshLayout.Header = new DefaultHeader(Activity);
                SwipeRefreshLayout.Footer = new MeituanFooter(Activity);
                SwipeRefreshLayout.SetEnable(true);
                SwipeRefreshLayout.SetListener(this);

                BtnAdd = (FloatingActionButton)view.FindViewById(Resource.Id.floatingAdd);
                BtnAdd.Visibility = ViewStates.Visible;

                BtnAdd.Click += BtnAddOnClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        private void InitToolbar(View view)
        {
            try
            {
                var toolbar = view.FindViewById<Toolbar>(Resource.Id.toolbar);
                GlobalContext.SetToolBar(toolbar,"",false); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private void SetRecyclerViewAdapters()
        {
            try
            {
                //Playlist RecyclerView
                PlaylistAdapter = new HPlaylistAdapter(Activity,true) { PlaylistList =  new ObservableCollection<PlaylistDataObject>() };
                PlaylistAdapter.OnItemClick += PlaylistAdapterOnOnItemClick;

                //Public Playlist RecyclerView
                PublicPlaylistAdapter = new HPlaylistAdapter(Activity) { PlaylistList = new ObservableCollection<PlaylistDataObject>() };
                PublicPlaylistAdapter.OnItemClick += PublicPlaylistAdapterOnOnItemClick;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
          
        #endregion

        #region Refresh

        public void OnRefresh()
        {
            try
            {
                PlaylistAdapter.PlaylistList.Clear();
                PlaylistAdapter.NotifyDataSetChanged();

                PublicPlaylistAdapter.PlaylistList.Clear();
                PublicPlaylistAdapter.NotifyDataSetChanged();

                EmptyStateLayout.Visibility = ViewStates.Gone;

                StartApiService();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void OnLoadMore()
        {
            try
            {
                if (PlaylistScrollEvent.IsLoading == false)
                {
                    PlaylistScrollEvent.IsLoading = true;
                    var item = PlaylistAdapter.PlaylistList.LastOrDefault();
                    if (item != null)
                    { 
                        GetPlaylist(item.Id.ToString()).ConfigureAwait(false);
                        PlaylistScrollEvent.IsLoading = false;
                    }
                }

                if (PublicPlaylistScrollEvent.IsLoading == false)
                {
                    PublicPlaylistScrollEvent.IsLoading = true;
                    var item = PublicPlaylistAdapter.PlaylistList.LastOrDefault();
                    if (item != null)
                    { 
                        GetPublicPlaylist(item.Id.ToString()).ConfigureAwait(false);
                        PublicPlaylistScrollEvent.IsLoading = false;
                    }
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion

        #region Get Public Playlist Api 

        private void StartApiService()
        {
            if (Methods.CheckConnectivity())
            {
                PollyController.RunRetryPolicyFunction(new List<Func<Task>> { () => GetPublicPlaylist(),() =>  GetPlaylist() });
            }
            else
            {
                SwipeRefreshLayout.OnFinishFreshAndLoad();

                Inflated = EmptyStateLayout.Inflate();
                EmptyStateInflater x = new EmptyStateInflater();
                x.InflateLayout(Inflated, EmptyStateInflater.Type.NoConnection);
                if (!x.EmptyStateButton.HasOnClickListeners)
                {
                    x.EmptyStateButton.Click += null;
                    x.EmptyStateButton.Click += EmptyStateButtonOnClick;
                }

                Toast.MakeText(Context, GetText(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Long).Show();
            }
        }
         
        private async Task GetPublicPlaylist(string offsetPublicPlaylist = "0")
        {
            int countList = PublicPlaylistAdapter.PlaylistList.Count;
            (int apiStatus, var respond) = await RequestsAsync.Playlist.GetPublicPlaylistAsync("20", offsetPublicPlaylist);
            if (apiStatus.Equals(200))
            {
                if (respond is PlaylistsObject result)
                {
                    var respondList = result.Playlists.Count;
                    if (respondList > 0)
                    {
                        if (countList > 0)
                        {
                            foreach (var item in result.Playlists)
                            {
                                var check = PublicPlaylistAdapter.PlaylistList.FirstOrDefault(a => a.Id == item.Id);
                                if (check == null)
                                {
                                    PublicPlaylistAdapter.PlaylistList.Add(item);
                                }
                            }

                            Activity.RunOnUiThread(() =>
                            {
                                PublicPlaylistAdapter.NotifyItemRangeInserted(countList - 1, PublicPlaylistAdapter.PlaylistList.Count - countList);
                            }); 
                        }
                        else
                        {
                            PublicPlaylistAdapter.PlaylistList = new ObservableCollection<PlaylistDataObject>(result.Playlists);

                            Activity.RunOnUiThread(() =>
                            {
                                if (PublicPlaylistInflated == null)
                                    PublicPlaylistInflated = PublicPlaylistViewStub.Inflate();

                                recyclerInflaterPublicPlaylist = new TemplateRecyclerInflater();
                                recyclerInflaterPublicPlaylist.InflateLayout<PlaylistDataObject>(Activity, PublicPlaylistInflated, PublicPlaylistAdapter, TemplateRecyclerInflater.TypeLayoutManager.LinearLayoutManagerHorizontal, 0, true, Activity.GetString(Resource.String.Lbl_Playlist));

                                if (PublicPlaylistScrollEvent == null)
                                {
                                    RecyclerViewOnScrollListener playlistRecyclerViewOnScrollListener = new RecyclerViewOnScrollListener(recyclerInflaterPublicPlaylist.LayoutManager);
                                    PublicPlaylistScrollEvent = playlistRecyclerViewOnScrollListener;
                                    PublicPlaylistScrollEvent.LoadMoreEvent += PublicPlaylistScrollEventOnLoadMoreEvent;
                                    recyclerInflaterPublicPlaylist.Recyler.AddOnScrollListener(playlistRecyclerViewOnScrollListener);
                                    PublicPlaylistScrollEvent.IsLoading = false;
                                }
                            }); 
                        }
                    }
                    else
                    {
                        if (recyclerInflaterPublicPlaylist.Recyler != null)
                            if (PublicPlaylistAdapter.PlaylistList.Count > 10 && !recyclerInflaterPublicPlaylist.Recyler.CanScrollVertically(1))
                                Toast.MakeText(Context, Context.GetText(Resource.String.Lbl_NoMorePlaylist), ToastLength.Short).Show();
                    }
                }
            }
            else Methods.DisplayReportResult(Activity, respond);

            PublicPlaylistScrollEvent.IsLoading = false;
            Activity.RunOnUiThread(ShowEmptyPage); 
        }

        private async Task GetPlaylist(string offsetPlaylist = "0")
        {
            int countList = PlaylistAdapter.PlaylistList.Count;
            (int apiStatus, var respond) = await RequestsAsync.Playlist.GetPlaylistAsync(UserDetails.UserId.ToString(), "20", offsetPlaylist);
            if (apiStatus.Equals(200))
            {
                if (respond is PlaylistsObject result)
                {
                    var respondList = result.Playlists.Count;
                    if (respondList > 0)
                    {
                        if (countList > 0)
                        {
                            foreach (var item in result.Playlists)
                            {
                                var check = PlaylistAdapter.PlaylistList.FirstOrDefault(a => a.Id == item.Id);
                                if (check == null)
                                {
                                    PlaylistAdapter.PlaylistList.Add(item);
                                }
                            }
                            PlaylistAdapter.NotifyItemRangeInserted(countList - 1, PlaylistAdapter.PlaylistList.Count - countList);
                        }
                        else
                        {
                            PlaylistAdapter.PlaylistList = new ObservableCollection<PlaylistDataObject>(result.Playlists);

                            if (PlaylistInflated == null)
                                PlaylistInflated = PlaylistViewStub.Inflate();

                            recyclerInflaterPlaylist = new TemplateRecyclerInflater();
                            recyclerInflaterPlaylist.InflateLayout<PlaylistDataObject>(Activity, PlaylistInflated, PlaylistAdapter, TemplateRecyclerInflater.TypeLayoutManager.LinearLayoutManagerHorizontal, 0, true, Activity.GetString(Resource.String.Lbl_MyPlaylist));
                            if (!recyclerInflaterPlaylist.MainLinear.HasOnClickListeners)
                            {
                                recyclerInflaterPlaylist.MainLinear.Click += null;
                                recyclerInflaterPlaylist.MainLinear.Click += PlaylistMoreOnClick;
                            }

                            if (PlaylistScrollEvent == null)
                            {
                                RecyclerViewOnScrollListener playlistRecyclerViewOnScrollListener = new RecyclerViewOnScrollListener(recyclerInflaterPlaylist.LayoutManager);
                                PlaylistScrollEvent = playlistRecyclerViewOnScrollListener;
                                PlaylistScrollEvent.LoadMoreEvent += PlaylistScrollEventOnLoadMoreEvent;
                                recyclerInflaterPlaylist.Recyler.AddOnScrollListener(playlistRecyclerViewOnScrollListener);
                                PlaylistScrollEvent.IsLoading = false;
                            }
                        }
                    }
                    else
                    {
                        if (recyclerInflaterPlaylist.Recyler != null)
                            if (PlaylistAdapter.PlaylistList.Count > 10 && !recyclerInflaterPlaylist.Recyler.CanScrollVertically(1))
                                Toast.MakeText(Context, Context.GetText(Resource.String.Lbl_NoMorePlaylist), ToastLength.Short).Show();
                    }
                }
            }
            else Methods.DisplayReportResult(Activity, respond);

            PlaylistScrollEvent.IsLoading = false;
            Activity.RunOnUiThread(ShowEmptyPage);

        }
         
        private void ShowEmptyPage()
        {
            try
            { 
                SwipeRefreshLayout.OnFinishFreshAndLoad();

                if (ProgressBar.Visibility == ViewStates.Visible)
                    ProgressBar.Visibility = ViewStates.Gone;
                 
                if (PublicPlaylistAdapter?.PlaylistList?.Count == 0 && PlaylistAdapter?.PlaylistList?.Count == 0)
                {

                    if (Inflated == null)
                        Inflated = EmptyStateLayout.Inflate();

                    EmptyStateInflater x = new EmptyStateInflater();
                    x.InflateLayout(Inflated, EmptyStateInflater.Type.NoPlaylist);
                    if (x.EmptyStateButton.HasOnClickListeners)
                    {
                        x.EmptyStateButton.Click += null;
                    }

                    EmptyStateLayout.Visibility = ViewStates.Visible;
                } 
            }
            catch (Exception e)
            {
                SwipeRefreshLayout.OnFinishFreshAndLoad();
                if (ProgressBar.Visibility == ViewStates.Visible)
                    ProgressBar.Visibility = ViewStates.Gone;
                Console.WriteLine(e);
            }
        }

        //No Internet Connection 
        private void EmptyStateButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                StartApiService(); 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion

        #region Scroll

        private void PublicPlaylistScrollEventOnLoadMoreEvent(object sender, EventArgs e)
        {
            try
            {
                //Code get last id where LoadMore >>
                var item = PublicPlaylistAdapter.PlaylistList.LastOrDefault(); 
                if (item != null && !string.IsNullOrEmpty(item.Id.ToString()))
                    GetPublicPlaylist(item.Id.ToString()).ConfigureAwait(false); 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        //My Playlist
        private void PlaylistScrollEventOnLoadMoreEvent(object sender, EventArgs e)
        {
            try
            {
                //Code get last id where LoadMore >>
                var item = PlaylistAdapter.PlaylistList.LastOrDefault();
                if (item != null && !string.IsNullOrEmpty(item.Id.ToString()))
                    GetPlaylist(item.Id.ToString()).ConfigureAwait(false); 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
         
        #endregion

        #region Event 
         
        private void PlaylistAdapterOnOnItemClick(object sender, PlaylistAdapterClickEventArgs e)
        {
            try
            {
                var item = PlaylistAdapter.PlaylistList[e.Position];
                if (item != null)
                {
                    Bundle bundle = new Bundle();
                    bundle.PutString("ItemData", JsonConvert.SerializeObject(item));
                    bundle.PutString("PlaylistId", item.Id.ToString());

                    PlaylistProfileFragment = new PlaylistProfileFragment
                    {
                        Arguments = bundle
                    };

                    GlobalContext.FragmentBottomNavigator.DisplayFragment(PlaylistProfileFragment);
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void PublicPlaylistAdapterOnOnItemClick(object sender, PlaylistAdapterClickEventArgs e)
        {
            try
            {
                var item = PublicPlaylistAdapter.PlaylistList[e.Position];
                if (item != null)
                {
                    Bundle bundle = new Bundle();
                    bundle.PutString("ItemData", JsonConvert.SerializeObject(item));
                    bundle.PutString("PlaylistId", item.Id.ToString());

                    PlaylistProfileFragment = new PlaylistProfileFragment
                    {
                        Arguments = bundle
                    };

                    GlobalContext.FragmentBottomNavigator.DisplayFragment(PlaylistProfileFragment);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        private void PlaylistMoreOnClick(object sender, EventArgs e)
        {
            try
            {
                MyPlaylistFragment = new MyPlaylistFragment();
                GlobalContext.FragmentBottomNavigator.DisplayFragment(MyPlaylistFragment);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        // Create Playlist
        private void BtnAddOnClick(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Activity, typeof(CreatePlaylistActivity)));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }

        #endregion
    }
}