﻿using System;
using Android.App;
using Android.Content;
using Android.Preferences;
using DeepSound.SQLite;

namespace DeepSound.Activities.SettingsUser
{
    public class SharedPref
    {
        #region Variables Basic

        public static ISharedPreferences SharedData;
        #endregion

        public static void Init()
        {
            try
            {
                SqLiteDatabase dbDatabase = new SqLiteDatabase();
                dbDatabase.CheckTablesStatus();
                SharedData = PreferenceManager.GetDefaultSharedPreferences(Application.Context);
                 
                bool getValue = SharedData.GetBoolean("Night_Mode_key", AppSettings.SetTabDarkTheme);
                if (getValue)
                { 
                    AppSettings.SetTabLightTheme = false;
                    AppSettings.SetTabColoredTheme = false;
                    AppSettings.SetTabDarkTheme = true;
                }
                else
                { 
                    AppSettings.SetTabLightTheme = true;
                    AppSettings.SetTabColoredTheme = false;
                    AppSettings.SetTabDarkTheme = false;
                } 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }
}