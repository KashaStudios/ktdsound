﻿using System;
using Android.Animation;
using Android.App;
using Android.Graphics;
using Android.OS;
using Android.Text;
using Android.Text.Method;
using Android.Text.Style;
using Android.Views;
using Com.Luseen.Autolinklibrary;
using DeepSound.Helpers.Controller;
using Java.Lang;
using Exception = Java.Lang.Exception;
using Object = Java.Lang.Object;

namespace DeepSound.Library.Anjo
{
    public class XTextViewAdvanced
    {
        public static readonly int TypeLine = 1;
        public static readonly int TypeCharacter = 2;

        // required
        private readonly Activity _activity;

        // optional
        public int TextLength;
        public int TextLengthType;
        public string MoreLabel;
        public string LessLabel;
        public Color MoreLabelColor;
        public Color LessLabelColor;
        public bool LabelUnderLine;
        public bool ExpandAnimation;
        public bool AutoLink;

        private XTextViewAdvanced(Builder builder)
        {
            _activity = builder.Activity;
            TextLength = builder.TextLength;
            TextLengthType = builder.TextLengthType;
            MoreLabel = builder.MoreLabel;
            LessLabel = builder.LessLabel;
            MoreLabelColor = builder.MoreLabelColor;
            LessLabelColor = builder.LessLabelColor;
            LabelUnderLine = builder.LabelUnderLine;
            ExpandAnimation = builder.ExpandAnimation;
            AutoLink = builder.AutoLink;
        }

        public void AddReadMoreTo(AutoLinkTextView textView, ICharSequence text)
        {
            if (TextLengthType == TypeCharacter)
            {
                if (text.Length() <= TextLength)
                {
                    if (AutoLink)
                    {
                        TextSanitizer changer = new TextSanitizer(textView, _activity);
                        changer.Load(text.ToString());
                    }
                    else
                    {
                        textView.Text = text.ToString(); //wael
                    }
                    return;
                }
            }
            else
            {
                // If TYPE_LINE
                textView.SetLines(TextLength);
                if (AutoLink)
                {
                    TextSanitizer changer = new TextSanitizer(textView, _activity);
                    changer.Load(text.ToString());
                }
                else
                {
                    textView.Text = text.ToString(); //wael
                } 
            }
             
            textView.Post(new MyRunnable(this, textView, text));
        }

        private class MyRunnable : Object, IRunnable
        {
            private readonly XTextViewAdvanced _advanced;
            private readonly AutoLinkTextView _textView;
            private readonly ICharSequence _text;

            public MyRunnable(XTextViewAdvanced advanced , AutoLinkTextView textView, ICharSequence text)
            {
                try
                {
                    _advanced = advanced;
                    _textView = textView;
                    _text = text;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void Run()
            {
                try
                {
                    int textLengthNew = _advanced.TextLength;

                    if (_advanced.TextLengthType == TypeLine)
                    {
                        if (_textView.Layout.LineCount <= _advanced.TextLength)
                        {
                            if (_advanced.AutoLink)
                            {
                                TextSanitizer changer = new TextSanitizer(_textView, _advanced._activity);
                                changer.Load(_text.ToString());
                            }
                            else
                            {
                                _textView.Text = _text.ToString(); //wael
                            }
                            
                            return;
                        }

                        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) _textView.LayoutParameters;

                        string subString = _text.SubSequence(_textView.Layout.GetLineStart(0),_textView.Layout.GetLineEnd(_advanced.TextLength - 1));
                        textLengthNew = subString.Length - (_advanced.MoreLabel.Length + 4 + lp.RightMargin / 6);
                    }

                    IAppendable spannableStringBuilder = new SpannableStringBuilder(_text.SubSequence(0, textLengthNew))
                        .Append("...")
                        .Append(_advanced.MoreLabel);

                    SpannableString ss = SpannableString.ValueOf(new Java.Lang.String(spannableStringBuilder.ToString())); //wael
                    MyClickableSpan clickableSpan = new MyClickableSpan(_advanced, _textView, _text, MyClickSpanType.ReadMore);

                    ss.SetSpan(clickableSpan, ss.Length() - _advanced.MoreLabel.Length, ss.Length(),
                        SpanTypes.ExclusiveExclusive);

                    if (Build.VERSION.SdkInt >= BuildVersionCodes.JellyBean && _advanced.ExpandAnimation)
                    {
                        LayoutTransition layoutTransition = new LayoutTransition();
                        layoutTransition.EnableTransitionType(LayoutTransitionType.Changing);
                        ((ViewGroup) _textView.Parent).LayoutTransition = layoutTransition;
                    }
                     
                    if (_advanced.AutoLink)
                    {
                        TextSanitizer changer = new TextSanitizer(_textView, _advanced._activity);
                        changer.Load(ss.ToString());
                    }
                    else
                    {
                        _textView.Text = ss.ToString(); //wael
                    }
                     
                    _textView.MovementMethod = LinkMovementMethod.Instance;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        private enum MyClickSpanType
        {
            ReadLess,
            ReadMore
        }

        private class MyClickableSpan : ClickableSpan
        {
            private readonly XTextViewAdvanced _advanced;
            private readonly AutoLinkTextView _textView;
            private readonly ICharSequence _text;
            private readonly MyClickSpanType _type;

            public MyClickableSpan(XTextViewAdvanced advanced , AutoLinkTextView textView, ICharSequence text, MyClickSpanType type)
            {
                try
                {
                    _advanced = advanced;
                    _textView = textView;
                    _text = text;
                    _type = type;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public override void OnClick(View widget)
            {
                switch (_type)
                {
                    case MyClickSpanType.ReadLess:
                        new Handler(Looper.MainLooper).Post(new Runnable(Run));
                        break;
                    default:
                        _advanced.AddReadLess(_textView, _text);
                        break;
                }

                
            }

            public void Run()
            {
                _advanced.AddReadMoreTo(_textView, _text);
            }


            public override void UpdateDrawState(TextPaint ds)
            {
                base.UpdateDrawState(ds);
                ds.UnderlineText = _advanced.LabelUnderLine;

                switch (_type)
                {
                    case MyClickSpanType.ReadLess:
                        ds.Color = _advanced.LessLabelColor;
                        break;
                    default:
                        ds.Color = _advanced.MoreLabelColor;
                        break;
                }
            }
        }

        public void AddReadLess(AutoLinkTextView textView, ICharSequence text)
        {
            textView.SetMaxLines(Integer.MaxValue);

            var spannableStringBuilder = new SpannableStringBuilder(text)
                .Append(LessLabel);

            SpannableString ss = SpannableString.ValueOf(new Java.Lang.String(spannableStringBuilder.ToString())); //wael

            MyClickableSpan clickableSpan = new MyClickableSpan(this, textView, text, MyClickSpanType.ReadLess);

            ss.SetSpan(clickableSpan, ss.Length() - LessLabel.Length, ss.Length(), SpanTypes.ExclusiveExclusive);
            if (AutoLink)
            {
                TextSanitizer changer = new TextSanitizer(textView, _activity);
                changer.Load(ss.ToString());
            }
            else
            {
                textView.Text = ss.ToString(); //wael
            }
             
            textView.MovementMethod = LinkMovementMethod.Instance;
        }

        public class Builder
        {
            // required
            public Activity Activity;

            // optional
            public int TextLength = 100;
            public int TextLengthType = TypeCharacter;
            public string MoreLabel = "read more";
            public string LessLabel = "read less";
            public Color MoreLabelColor = Color.ParseColor("#ff00ff");
            public Color LessLabelColor = Color.ParseColor("#ff00ff");
            public bool LabelUnderLine;
            public bool ExpandAnimation;
            public bool AutoLink;

            public Builder(Activity activity)
            {
                Activity = activity;
            }

            public Builder SetTextLength(int length, int textLengthType)
            {
                TextLength = length;
                TextLengthType = textLengthType;
                return this;
            }

            public Builder SetMoreLabel(string moreLabel)
            {
                MoreLabel = moreLabel;
                return this;
            }

            public Builder SetLessLabel(string lessLabel)
            {
                LessLabel = lessLabel;
                return this;
            }

            public Builder SetMoreLabelColor(Color moreLabelColor)
            {
                MoreLabelColor = moreLabelColor;
                return this;
            }

            public Builder SetLessLabelColor(Color lessLabelColor)
            {
                LessLabelColor = lessLabelColor;
                return this;
            }

            public Builder SetLabelUnderLine(bool labelUnderLine)
            {
                LabelUnderLine = labelUnderLine;
                return this;
            }

            public Builder SetExpandAnimation(bool expandAnimation)
            {
                ExpandAnimation = expandAnimation;
                return this;
            }
            public Builder SetAutoLink(bool autoLink)
            {
                AutoLink = autoLink;
                return this;
            }

            public XTextViewAdvanced Build()
            {
                return new XTextViewAdvanced(this);
            }

        }
    }
}